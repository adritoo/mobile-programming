package fr.android.project_bourget;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class AccesFirebase extends AppCompatActivity {

    private static final String TAG = "ACCES_FIRESBASE" ;
    DatabaseReference myRef;
    private Button btn_recherche;
    private EditText what;
    private TextView date, player1, player2, score, winner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acces_firebase);
        btn_recherche = findViewById(R.id.btn_recherche);
        what = findViewById(R.id.what);
        date = findViewById(R.id.date);
        player1 = findViewById(R.id.player1);
        player2 = findViewById(R.id.player2);
        score = findViewById(R.id.score);
        winner = findViewById(R.id.winner);

        btn_recherche.setOnClickListener(new View.OnClickListener(){

             @Override
             public void onClick(View v){

                 String str = what.getText().toString();
                 myRef = FirebaseDatabase.getInstance().getReference().child("Matchs").child(str);
                 myRef.addValueEventListener(new ValueEventListener() {

                     @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        String mdate = dataSnapshot.child("Date").getValue().toString();
                        String mplayer1 = dataSnapshot.child("Joueur 1").getValue().toString();
                        String mplayer2 = dataSnapshot.child("Joueur 2").getValue().toString();
                        String mwinner = dataSnapshot.child("Vainqueur").getValue().toString();
                        String mscore = dataSnapshot.child("Score").getValue().toString();

                        date.setText(mdate);
                        player1.setText(mplayer1);
                        player2.setText(mplayer2);
                        score.setText(mscore);
                        winner.setText(mwinner);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                        Log.w(TAG, "Failed to read value.", error.toException());
                    }
                });
            }
        });
    }

}
