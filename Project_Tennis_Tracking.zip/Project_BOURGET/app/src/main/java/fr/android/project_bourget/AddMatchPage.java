package fr.android.project_bourget;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class AddMatchPage extends AppCompatActivity implements LocationListener {

    DatabaseHelper mDatabaseHelper;
    private Button saveMatch, viewData, picture;
    private EditText namePlayer1, namePlayer2, dateMatch, longitudeMatch, latitudeMatch;

    private LocationManager locationManager;
    Geocoder geocoder;
    List<Address> addresses;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        geocoder = new Geocoder(this,Locale.getDefault());
        setContentView(R.layout.activity_add_match_page);
        saveMatch = findViewById(R.id.saveMatch);
        viewData = findViewById(R.id.viewData);
        mDatabaseHelper = new DatabaseHelper(this);
        namePlayer1 = findViewById(R.id.namePlayer1);
        namePlayer2 = findViewById(R.id.namePlayer2);
        dateMatch = findViewById(R.id.dateMatch);
        longitudeMatch = findViewById(R.id.longitudeMatch);
        latitudeMatch = findViewById(R.id.latitudeMatch);
        picture = findViewById(R.id.picture);


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        assert location != null;
        onLocationChanged(location);

        saveMatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String player1 = namePlayer1.getText().toString();
                String player2 = namePlayer2.getText().toString();
                String date = dateMatch.getText().toString();
                String latitude = latitudeMatch.getText().toString();
                String longitude = longitudeMatch.getText().toString();

                if((namePlayer1.length() != 0) && (namePlayer2.length() != 0)){
                    addData(player1, player2, date, latitude, longitude);
                    namePlayer1.setText("");
                    namePlayer2.setText("");
                    dateMatch.setText("");
                    latitudeMatch.setText("");
                    longitudeMatch.setText("");
                }else{
                    toastMessage("You must put something into the text field");
                }
            }
        });

        picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(AddMatchPage.this, PhotoActivity.class);
                startActivity(intent);
            }
        });

        viewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddMatchPage.this, ListDataActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addData(String player1, String player2, String date, String latitude, String longitude){
        boolean insertData = mDatabaseHelper.addData(player1, player2, date, latitude, longitude);
        if(insertData){
            toastMessage("Data Successfully Added");
        }else{
            toastMessage("Somethings went wrong!");
        }
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onLocationChanged(Location location) {
        double longitude = location.getLongitude();
        double latitude = location.getLatitude();
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        toastMessage(String.valueOf(addresses));
        longitudeMatch.setText(String.valueOf(longitude), TextView.BufferType.EDITABLE);
        latitudeMatch.setText(String.valueOf(latitude), TextView.BufferType.EDITABLE);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}

