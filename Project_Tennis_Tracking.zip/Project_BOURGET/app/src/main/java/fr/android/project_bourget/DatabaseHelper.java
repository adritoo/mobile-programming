package fr.android.project_bourget;

        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String TABLE_NAME = "match_table";
    private static final String COL1 = "ID";
    private static final String COL2 = "player_one";
    private static final String COL3 = "player_two";
    private static final String COL4 = "date";
    private static final String COL5 = "latitude";
    private static final String COL6 = "longitude";


    public DatabaseHelper(Context context){
        super(context, TABLE_NAME, null, 4);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "( ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COL2 + " TEXT, "
                + COL3 + " TEXT, " +COL4 + " TEXT, "+ COL5 + " TEXT, "+ COL6+ " TEXT"+ ");";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String player1, String player2, String date, String longitude, String latitude){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL2, player1);
        values.put(COL3, player2);
        values.put(COL4, date);
        values.put(COL5, latitude);
        values.put(COL6, longitude);
        Log.d(TAG, "addData: Adding " + player1 + " to " + TABLE_NAME);
        Log.d(TAG, "addData: Adding " + player2 + " to " + TABLE_NAME);
        Log.d(TAG, "addData: Adding " + date + " to " + TABLE_NAME);
        Log.d(TAG, "addData: Adding " + latitude + " to " + TABLE_NAME);
        Log.d(TAG, "addData: Adding " + longitude + " to " + TABLE_NAME);
        long result = db.insert(TABLE_NAME, null, values);

        return result != (-1);
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String querry = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(querry, null);
        return data;
    }
}
