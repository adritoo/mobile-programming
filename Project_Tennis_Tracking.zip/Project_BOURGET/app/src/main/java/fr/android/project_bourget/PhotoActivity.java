package fr.android.project_bourget;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;

public class PhotoActivity extends AppCompatActivity {
    // Contantes
    private static final int RETOUR_PRISE_PHOTO = 1;

    // Propriétés
    private Button btnPhoto;
    private ImageView imageView;
    private String photoPath = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initActivity();
    }

    /**
     * initialisation de l'activité
     */
    private void initActivity(){
        //Récupération des éléments graphiques
        btnPhoto = findViewById(R.id.btnPhoto);
        imageView = findViewById(R.id.imgView);
        createOnClickPrendrePhoto();
    }


    /**
     * Evènement clique sur boutton Btn_photo
     */
    private void createOnClickPrendrePhoto(){
        btnPhoto.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                prendreUnePhoto();
            }
        });
    }

    /**
     * Accès à l'appareil photo et l'enregistre dans un fichier temporaire
     */
    @RequiresApi()
    private void prendreUnePhoto(){
        //  Créer un intent pour ouvrir une nouvelle fênetre et prendre la photo
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        // Controle de l'intent; celui ci peut être géré (le téléphone a bien un appareil photo)
        if(intent.resolveActivity(getPackageManager()) != null){
            // On créer un nom de fichier temporaire hh.mm.ss
            String time = new SimpleDateFormat("yyyyMMdd__HHss").format(new Date());
            File photoDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            try {
                File photoFile = File.createTempFile("photo" + time, ".jpg", photoDir);
                photoPath = photoFile.getAbsolutePath();
                // Créer l'URI (le code spécifique qui permet d'obtenir l'accès au fichier)
                Uri photoUri = FileProvider.getUriForFile(PhotoActivity.this,
                        PhotoActivity.this.getApplicationContext().getPackageName()+".provider", photoFile);
                // Transfert vers l'intent pour enregistrement dans fichier temporaire
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                // Ouvrir l'activité par rapport à l'intent
                startActivityForResult(intent, RETOUR_PRISE_PHOTO);
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    /** Retour de l'appel de l'appareil photo (startActivityForResult)
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        // Verifie que le code est ok
        if(requestCode==RETOUR_PRISE_PHOTO && resultCode==RESULT_OK){
            //Récup de l'image
            Bitmap image = BitmapFactory.decodeFile(photoPath);
            //Afficher l'image
            imageView.setImageBitmap(image);
        }

    }
}
