package fr.android.project_bourget;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StartPage extends AppCompatActivity {

    // Propriétés
    private Button btnAddMatch;
    private Button btnAccesData;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("message");


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.starting_page);
        initActivity();

    }

    protected void initActivity(){
        btnAddMatch = findViewById(R.id.btnAddMatch);
        btnAccesData = findViewById(R.id.btnAccesData);
        createOnClickAddMatch();
        createOnClickAccesData();
    }

    private void createOnClickAddMatch(){
        btnAddMatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMatch();
            }
        });
    }

    private void createOnClickAccesData(){
        btnAccesData.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                accesData();
            }
        });
    }

    private void addMatch(){
        startActivity(new Intent(this, AddMatchPage.class));
    }

    private void accesData(){
        startActivity(new Intent(this, AccesFirebase.class));
    }

}
