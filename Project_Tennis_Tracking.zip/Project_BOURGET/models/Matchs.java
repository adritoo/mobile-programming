public class Matchs {

    private String mid; // Id du match
    private String joueur1; // Nom du joueur 1
    private String joueur2; // Nom du joueur 2
    @Nullable private String urlPic; //Photo du match

    public Matchs(){}

    public Matchs(String mid, String joueur1, String joueur2, String urlPic){
        this.mid = mid;
        this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.urlPic = urlPic;
    }

    public String getJoueur1() {
        return joueur1;
    }

    public String getJoueur2() {
        return joueur2;
    }

    public String getMid() {
        return mid;
    }

    public String getUrlPic() {
        return urlPic;
    }

    public void setJoueur1(String joueur1) {
        this.joueur1 = joueur1;
    }

    public void setJoueur2(String joueur2) {
        this.joueur2 = joueur2;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public void setUrlPic(String urlPic) {
        this.urlPic = urlPic;
    }
}
