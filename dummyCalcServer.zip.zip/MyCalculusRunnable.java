import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

class MyCalculusRunnable implements Runnable {
    private Socket sock;

    public MyCalculusRunnable(Socket s) {
        sock = s;
    }

    @Override
    public void run() {

        try {
            DataInputStream dis = new DataInputStream(sock.getInputStream());
            DataOutputStream dos = new DataOutputStream(sock.getOutputStream());

/*
			while(dis.available()>0) {
            	System.out.print(dis.readChar());
      		}
            dis.close();
            dos.close();
            sock.close();
			return;
*/

            // read op1, op2 and the opreation to make
            Double op1 = dis.readDouble();
            char op = dis.readChar();
            Double op2 = dis.readDouble();

			System.err.println("op1: " + op1);
			System.err.println("op: " + op);
			System.err.println("op2: " + op2);

            Double res = CalculusServer.doOp(op1, op2, op);

			System.out.println("the asked result was " + res);

            // send back result
            dos.writeDouble(res);

            dis.close();
            dos.close();
            sock.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
