import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TestClass {

    public static void main(String[] args) throws Exception {

        // Example of a distant calculator
        Socket sock = new Socket("127.0.0.1", 9876);

		DataInputStream dis = new DataInputStream(sock.getInputStream());
		DataOutputStream dos = new DataOutputStream(sock.getOutputStream());

		dos.writeDouble(Double.parseDouble(args[0]));
		dos.writeChar(args[1].charAt(0));
		dos.writeDouble(Double.parseDouble(args[2]));


		System.out.println("result is " + dis.readDouble());

		dos.close();
		dis.close();
		sock.close();

    }
}
